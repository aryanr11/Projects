var express = require('express');
var router = express.Router();

var userController = require('../controllers/user')
var stationController = require('../controllers/station')
var serviceController = require('../controllers/service')


// User

router.post('/user/signup', userController.userSignup);

router.post('/user/login', userController.userLogin);

router.get('/user/find', userController.sequre , userController.userAllData);

router.delete('/user/delete/:deleteId', userController.userDelete);

router.put('/user/update/:updateId', userController.userUpdate);


// Station

router.post('/station/signup', stationController.stationSignup);

router.post('/station/login', stationController.stationLogin);

router.get('/station/find', stationController.stationAllData);

router.delete('/station/delete/:deleteId', stationController.stationDelete);

router.put('/station/update/:updateId', stationController.stationUpdate);


// Service

router.post('/service/create', serviceController.serviceCreate);

router.get('/service/find', serviceController.serviceAllData);

router.delete('/service/delete/:deleteId', serviceController.serviceDelete);

router.put('/service/update/:updateId', serviceController.serviceUpdate);



module.exports = router;