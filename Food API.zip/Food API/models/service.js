const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const serviceSchema = new Schema({
  foodName: {
    type : String,
    require : true
  },
  price: {
    type : String,
    require : true
  },
  order: {
    type : String,
    enum : ["pending" , "done"],
    default : "pending",
  },
  email: {
    type : String,
    unique : true,
    require : true
  }
})

const SERVICE = mongoose.model('service',serviceSchema)
  
module.exports = SERVICE