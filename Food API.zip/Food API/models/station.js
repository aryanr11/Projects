const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const stationSchema = new Schema({
  shopName: {
    type : String,
    require : true
  },
  location: {
    type : String,
    require : true
  },
  email: {
    type : String,
    unique : true,
    require : true
  },
  password : {
    type : String,
    require : true
  }
})

const STATION = mongoose.model('station',stationSchema)

module.exports = STATION