var SERVICE = require('../models/service')
const bcrypt = require('bcrypt');

// service Create  
exports.serviceCreate = async function (req, res, next) {
    try {

        let serviceData = await SERVICE.create(req.body)

        if (!serviceData) {
            throw new Error('service Not Found')
        }

        res.status(201).json({
            status: "Success",
            message: "service create Successfully",
            data: serviceData
        })
    }
    catch (error) {
        res.status(404).json({
            status: "fail",
            message: error.message
        })
    }
}

// service All Data
exports.serviceAllData = async function(req, res, next) {
    try {
        
        let serviceFind = await SERVICE.find()
        if(!serviceFind){
            throw new Error('service Not Found')
        }

        res.status(201).json({
            status : "Success",
            message : "service All Data Successfully",
            data : serviceFind
        })  
    }
    catch (error) {
        res.status(404).json({
            status : "fail",
            message : error.message
        })  
    }
}

// service Delete
exports.serviceDelete = async function(req, res, next) {
    try {
        
        let serviceDelete = await SERVICE.findByIdAndDelete(req.params.deleteId)
        if(!serviceDelete){
            throw new Error('service Not Found')
        }

        res.status(201).json({
            status : "Success",
            message : "service Delete Successfully",
            data : serviceDelete
        })  
    }
    catch (error) {
        res.status(404).json({
            status : "fail",
            message : error.message
        })  
    }
}

// service Update
exports.serviceUpdate = async function(req, res, next) {
    try {
        
        req.body.password = await bcrypt.hash(req.body.password,8)

        let serviceUpdate = await SERVICE.findByIdAndUpdate(req.params.updateId,req.body)
        if(!serviceUpdate){
            throw new Error('service Not Found')
        }

        res.status(201).json({
            status : "Success",
            message : "service Update Successfully",
            data : serviceUpdate
        })
    }
    catch (error) {
        res.status(404).json({
            status : "fail",
            message : error.message
        })  
    }
}