var USER = require('../models/user')
const bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');


// Sequre
exports.sequre = async function (req, res, next) {
    try {

        let token = req.headers.token
        if (!token) {
            throw new Error('Please Send Token')
        }

        let decoded = jwt.verify(token, 'SURAT');

        let usercheck = await USER.findById(decoded.id)
        if (!usercheck) {
            throw new Error('User Not Found')
        }

        next()

    }
    catch (error) {
        res.status(404).json({
            status: "fail",
            message: error.message
        })
    }
}

// User SignUp  
exports.userSignup = async function (req, res, next) {
    try {

        req.body.password = await bcrypt.hash(req.body.password , 8)

        let userSignup = await USER.create(req.body)
        if (!userSignup) {
            throw new Error('User Not Found')
        }

        res.status(201).json({
            status: "Success",
            message: "User Signup Successfully",
            data: userSignup
        })
    }
    catch (error) {
        res.status(404).json({
            status: "fail",
            message: error.message
        })
    }
}

// User Login
exports.userLogin = async function(req, res, next) {
    try {
        
        let userLogin = await USER.findOne({ email: req.body.email })
        if(!userLogin){
            throw new Error('User Not Found')
        }

        let PassComp = await bcrypt.compare(req.body.password , userLogin.password)
        if(!PassComp){
            throw new Error('Invalid Password')
        }

        var token = jwt.sign({ id: userLogin._id }, 'SURAT');

        res.status(201).json({
            status : "Success",
            message : "User Login Successfully",
            data : userLogin,
            token
        })  
    }
    catch (error) {
        res.status(404).json({
            status : "fail",
            message : error.message
        })  
    }
}

// User All Data
exports.userAllData = async function(req, res, next) {
    try {
        
        let userFind = await USER.find()
        if(!userFind){
            throw new Error('User Not Found')
        }

        res.status(201).json({
            status : "Success",
            message : "User All Data Successfully",
            data : userFind
        })  
    }
    catch (error) {
        res.status(404).json({
            status : "fail",
            message : error.message
        })  
    }
}

// User Delete
exports.userDelete = async function(req, res, next) {
    try {
        
        let userDelete = await USER.findByIdAndDelete(req.params.deleteId)
        if(!userDelete){
            throw new Error('User Not Found')
        }

        res.status(201).json({
            status : "Success",
            message : "User Delete Successfully",
            data : userDelete
        })  
    }
    catch (error) {
        res.status(404).json({
            status : "fail",
            message : error.message
        })  
    }
}

// User Update
exports.userUpdate = async function(req, res, next) {
    try {
        
        req.body.password = await bcrypt.hash(req.body.password,8)

        let userUpdate = await USER.findByIdAndUpdate(req.params.updateId,req.body)
        if(!userUpdate){
            throw new Error('User Not Found')
        }

        res.status(201).json({
            status : "Success",
            message : "User Update Successfully",
            data : userUpdate
        })
    }
    catch (error) {
        res.status(404).json({
            status : "fail",
            message : error.message
        })  
    }
}