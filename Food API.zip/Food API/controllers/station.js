var STATION = require('../models/station')
const bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');


// station SignUp  
exports.stationSignup = async function (req, res, next) {
    try {

        req.body.password = await bcrypt.hash(req.body.password , 8)

        let stationSignup = await STATION.create(req.body)
        if (!stationSignup) {
            throw new Error('station Not Found')
        }

        res.status(201).json({
            status: "Success",
            message: "station Signup Successfully",
            data: stationSignup
        })
    }
    catch (error) {
        res.status(404).json({
            status: "fail",
            message: error.message
        })
    }
}

// station Login
exports.stationLogin = async function(req, res, next) {
    try {
        
        let stationLogin = await STATION.findOne({ email: req.body.email })
        if(!stationLogin){
            throw new Error('station Not Found')
        }

        let PassComp = await bcrypt.compare(req.body.password , stationLogin.password)
        if(!PassComp){
            throw new Error('Invalid Password')
        }

        res.status(201).json({
            status : "Success",
            message : "station Login Successfully",
            data : stationLogin
        })  
    }
    catch (error) {
        res.status(404).json({
            status : "fail",
            message : error.message
        })  
    }
}

// station All Data
exports.stationAllData = async function(req, res, next) {
    try {
        
        let stationFind = await STATION.find()
        if(!stationFind){
            throw new Error('station Not Found')
        }

        res.status(201).json({
            status : "Success",
            message : "station All Data Successfully",
            data : stationFind
        })  
    }
    catch (error) {
        res.status(404).json({
            status : "fail",
            message : error.message
        })  
    }
}

// station Delete
exports.stationDelete = async function(req, res, next) {
    try {
        
        let stationDelete = await STATION.findByIdAndDelete(req.params.deleteId)
        if(!stationDelete){
            throw new Error('station Not Found')
        }

        res.status(201).json({
            status : "Success",
            message : "station Delete Successfully",
            data : stationDelete
        })  
    }
    catch (error) {
        res.status(404).json({
            status : "fail",
            message : error.message
        })  
    }
}

// station Update
exports.stationUpdate = async function(req, res, next) {
    try {
        
        req.body.password = await bcrypt.hash(req.body.password,8)

        let stationUpdate = await STATION.findByIdAndUpdate(req.params.updateId,req.body)
        if(!stationUpdate){
            throw new Error('station Not Found')
        }

        res.status(201).json({
            status : "Success",
            message : "station Update Successfully",
            data : stationUpdate
        })
    }
    catch (error) {
        res.status(404).json({
            status : "fail",
            message : error.message
        })  
    }
}