document.write("<h1>10 To 1 In Loop</h1>")
var i=10

document.write("<h3>While Loop</h3>")

while(i>=1){
    document.write(i+"<br>")
    i--;
}

document.write("<h3>Do While Loop</h3>")

var i=10
do{
    document.write(i+"<br>")
    i--;
}
while(i>=1)


document.write("<h3>For Loop</h3>")

var i=10
for(i=10;i>=1;i--){
    document.write(i+"<br>")
}