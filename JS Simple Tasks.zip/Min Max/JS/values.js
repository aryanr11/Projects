var a=10
var b=20
var c=30
var d=40
var e=50

document.write("<h1>-: Vales :-</h1>")
document.write("<h2>a = "+a)
document.write("<h2>b = "+b)
document.write("<h2>c = "+c)
document.write("<h2>d = "+d)
document.write("<h2>e = "+e)
document.write("</h2>")