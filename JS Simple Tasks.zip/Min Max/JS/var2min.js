document.write("<h1>2 Variable Min A & B</h1>")

if(a<b)
{
    document.write("<h3>A is MIN</h3>")
}
else
{
    document.write("<h3>B is MIN<h3>")
}