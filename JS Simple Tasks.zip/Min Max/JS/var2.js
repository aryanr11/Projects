document.write("<h1>2 Variable Max A & B</h1>")

if(a>b)
{
    document.write("<h3>A is MAX</h3>")
}
else
{
    document.write("<h3>B is MAX<h3>")
}