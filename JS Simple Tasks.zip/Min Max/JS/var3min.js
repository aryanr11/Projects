document.write("<h1>3 Variable Min A & B & C</h1>")

if(a<b)
{
    if(a<c)
    {
        document.write("<h3>A is MIN</h3>")
    }
    else
    {
        document.write("<h3>C is MIN</h3>")
    }
}
else
{
    if(b<c)
    {
        document.write("<h3>B is MIN</h3>")
    }
    else
    {
        document.write("<h3>C is MIN</h3>")
    }
}